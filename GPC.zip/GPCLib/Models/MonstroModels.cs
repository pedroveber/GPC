﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace GPCLib.Models
{
    public class MonstroModels
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Imagem { get; set; }
    }
}
